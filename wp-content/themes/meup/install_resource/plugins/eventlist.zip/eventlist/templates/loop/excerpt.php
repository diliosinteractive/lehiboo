<?php if( ! defined( 'ABSPATH' ) ) exit(); ?>

<div class="event_excerpt">
	<?php the_excerpt(); ?>
</div>
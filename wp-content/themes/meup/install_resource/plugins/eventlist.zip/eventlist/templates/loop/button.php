<?php if ( ! defined( 'ABSPATH' ) ) exit(); ?>
<span class="event-button">
	<a class="second_font" href="<?php the_permalink(); ?>"><?php echo esc_html__( 'Get Ticket' , 'eventlist')  ?></a>
</span>
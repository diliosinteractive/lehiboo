<?php if( ! defined( 'ABSPATH' ) ) exit();

el_get_template( 'archive-event.php' );
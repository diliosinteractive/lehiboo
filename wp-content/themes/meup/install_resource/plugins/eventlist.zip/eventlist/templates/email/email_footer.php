<?php
if ( ! defined( 'ABSPATH' ) ) {
exit; // Exit if accessed directly
}
?>
                            <!-- START FOOTER -->
                            <div class="footer">
                            </div>
                            <!-- END FOOTER -->

                        </div>
                    </td>
                <td>&nbsp;</td>
            </tr>
        </table>
    </body>
</html>
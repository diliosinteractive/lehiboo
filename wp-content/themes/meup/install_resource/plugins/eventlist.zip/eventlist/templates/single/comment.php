<?php if( ! defined( 'ABSPATH' ) ) exit();
global $post;
?>

<div class="event_comments event_section_white">
	<?php comments_template(); ?>
</div>

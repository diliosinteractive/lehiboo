<?php if( ! defined( 'ABSPATH' ) ) exit(); ?>
<div class="element_package <?php echo esc_attr( $args['class'] ); ?>">
	<?php el_get_template( 'vendor/_package_content.php' ); ?>
</div>
